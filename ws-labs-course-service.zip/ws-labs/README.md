# WSD4302 - Web Services Development (Java EE / Jakarta EE)

Cumulative laboratory repository. Each week extends the same Maven project.

## Lab 1: Create and inspect a Maven web application

A minimal Jakarta web application (`course-service`) with one endpoint, `GET /health`.

### Prerequisites (record the exact versions you used)

| Tool | Version used |
|---|---|
| JDK (Eclipse Temurin) | 21.0.12 |
| Apache Maven | 3.9.16 |
| Apache Tomcat | 10.1.x  (fill in your exact version) |
| Git | (fill in: `git --version`) |
| curl | (fill in: `curl --version`) |

Tomcat must be 10.1 or newer (Jakarta namespace `jakarta.*`). Tomcat 9 will not work.

### Build

```
cd course-service
mvn clean verify
```

Result: `target\course-service.war`

### Run

```
copy target\course-service.war <TOMCAT_HOME>\webapps\
<TOMCAT_HOME>\bin\catalina.bat run
```

`JAVA_HOME` must point to the JDK. Stop Tomcat with `Ctrl+C`.

### Test / verification commands

With Tomcat running, in another terminal:

```
curl -i http://localhost:8080/course-service/health
curl -i http://localhost:8080/course-service/nope
curl -i -X POST http://localhost:8080/course-service/health
curl -v http://localhost:8080/course-service/health
```

Or run all cases at once: `course-service\scripts\verify.cmd`

| Case | Command | Expected |
|---|---|---|
| Success | `GET /health` | `200 OK`, JSON `{"status":"UP","service":"course-service"}` |
| Missing resource | `GET /nope` | `404 Not Found` |
| Wrong method | `POST /health` | `405 Method Not Allowed` |
| Repeat | `GET /health` x3 | identical response each time |
| Build | `mvn clean verify` | `BUILD SUCCESS` |

### Project layout

```
course-service/
  pom.xml
  scripts/verify.cmd
  src/main/java/edu/example/course/HealthServlet.java
  src/main/webapp/WEB-INF/web.xml      (Servlet 6.0 descriptor)
  src/main/webapp/index.jsp
```
