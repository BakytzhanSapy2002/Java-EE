<html>
<body>
<h2>course-service is running</h2>
<p>Try <code>/course-service/health</code></p>
</body>
</html>
