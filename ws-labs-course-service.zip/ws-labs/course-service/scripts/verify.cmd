@echo off
rem Manual verification script for Lab 1 (Tomcat must be running).
setlocal
set BASE=http://localhost:8080/course-service

echo === 1. Success: GET /health ===
curl.exe -i %BASE%/health
echo.
echo === 2. Missing resource: GET /nope ===
curl.exe -i %BASE%/nope
echo.
echo === 3. Wrong method: POST /health ===
curl.exe -i -X POST %BASE%/health
echo.
echo === 4. Repeat: GET /health three times ===
for /L %%i in (1,1,3) do curl.exe -s -o NUL -w "attempt %%i: HTTP %%{http_code}\n" %BASE%/health
echo.
echo === 5. Full exchange: GET /health with -v ===
curl.exe -v %BASE%/health
endlocal
