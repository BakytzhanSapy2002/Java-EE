<html>
<body>
<h2>course-service</h2>
<p>API: <a href="courses">/courses</a> &middot; Health: <a href="health">/health</a></p>
</body>
</html>
