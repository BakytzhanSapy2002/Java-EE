package edu.example.course.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Клиенттен келетін JSON денесі. 3-лабта тек жай POJO/record,
 * 5-лабта @NotBlank/@Size аннотациялары арқылы Bean Validation қосылады
 * (контейнер автоматты тексереді, қолмен if/else жазудың қажеті жоқ).
 */
public record CourseInput(
        @NotBlank(message = "code бос болмауы керек")
        @Size(max = 20, message = "code 20 таңбадан аспауы керек")
        String code,

        @NotBlank(message = "title бос болмауы керек")
        @Size(max = 120, message = "title 120 таңбадан аспауы керек")
        String title
) {}
