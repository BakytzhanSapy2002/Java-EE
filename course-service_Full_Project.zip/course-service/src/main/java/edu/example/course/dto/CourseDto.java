package edu.example.course.dto;

import edu.example.course.model.Course;
import java.time.Instant;

/** JAX-RS/JSON-B осы record-ты автоматты түрде JSON-ға айналдырады. */
public record CourseDto(long id, String code, String title, Instant createdAt) {
    public static CourseDto from(Course c) {
        return new CourseDto(c.getId(), c.getCode(), c.getTitle(), c.getCreatedAt());
    }
}
