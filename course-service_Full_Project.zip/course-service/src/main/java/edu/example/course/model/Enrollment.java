package edu.example.course.model;

import jakarta.persistence.*;
import java.time.Instant;

/**
 * Student пен Course арасындағы байланыс кестесі (PDF-тегі 4-лаб мысалы
 * дәл осы атаумен берілген). @ManyToOne(optional=false) — Enrollment
 * жазбасы курссыз немесе студентсіз болуы МҮМКІН ЕМЕС дегенді білдіреді
 * (дерекқор деңгейінде NOT NULL FK шектеуі).
 */
@Entity
@Table(name = "enrollments",
       uniqueConstraints = @UniqueConstraint(columnNames = {"student_id", "course_id"}))
public class Enrollment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "student_id")
    private Student student;

    @ManyToOne(optional = false)
    @JoinColumn(name = "course_id")
    private Course course;

    @Column(name = "enrolled_at", nullable = false)
    private Instant enrolledAt;

    protected Enrollment() { }

    public Enrollment(Student student, Course course) {
        this.student = student;
        this.course = course;
        this.enrolledAt = Instant.now();
    }

    public Long getId() { return id; }
    public Student getStudent() { return student; }
    public Course getCourse() { return course; }
    public Instant getEnrolledAt() { return enrolledAt; }
}
