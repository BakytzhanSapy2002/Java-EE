package edu.example.course.exception;

import edu.example.course.dto.ErrorResponse;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.util.List;

/**
 * @Valid аннотациясы бұзылғанда (мысалы, CourseInput.code бос болса)
 * контейнер ConstraintViolationException лақтырады. Бұл mapper оны
 * бірыңғай ErrorResponse-ке, әр өрістің нақты хабарламасымен бірге
 * келтіреді ("useful field-level message" талабы).
 */
@Provider
public class ValidationExceptionMapper implements ExceptionMapper<ConstraintViolationException> {

    @Override
    public Response toResponse(ConstraintViolationException exception) {
        List<String> details = exception.getConstraintViolations().stream()
                .map(v -> v.getPropertyPath() + ": " + v.getMessage())
                .toList();

        return Response.status(400)
                .type(MediaType.APPLICATION_JSON)
                .entity(new ErrorResponse(400, "Валидация қатесі", details))
                .build();
    }
}
