package edu.example.course.exception;

/** Сыртқы қызмет сәтсіз жауап берсе немесе қолжетімсіз болса лақтырылады. */
public class UpstreamException extends RuntimeException {
    public UpstreamException(String message) { super(message); }
    public UpstreamException(String message, Throwable cause) { super(message, cause); }
}
