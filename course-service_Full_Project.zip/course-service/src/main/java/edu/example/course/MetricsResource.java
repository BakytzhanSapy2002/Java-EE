package edu.example.course;

import edu.example.course.observability.MetricsRegistry;
import jakarta.annotation.security.PermitAll;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.util.Map;

/** 10-лаб: қарапайым метрика endpoint-і (Prometheus форматы емес, оқу мақсатына жеткілікті). */
@Path("/metrics")
@Produces(MediaType.APPLICATION_JSON)
public class MetricsResource {

    @Inject
    private MetricsRegistry metrics;

    @GET
    @PermitAll
    public Map<String, Long> get() {
        return metrics.snapshot();
    }
}
