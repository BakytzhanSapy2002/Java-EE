package edu.example.course.observability;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 10-лаб: ең қарапайым метрика жинағышы — сыртқы кітапхана (Micrometer,
 * Prometheus client) қоспай-ақ, негізгі идеяны көрсетеді: сұраныстар мен
 * қателерді санау, нәтижені /metrics арқылы шығару.
 */
@ApplicationScoped
public class MetricsRegistry {

    private final Map<String, AtomicLong> counters = new ConcurrentHashMap<>();

    public void increment(String name) {
        counters.computeIfAbsent(name, k -> new AtomicLong()).incrementAndGet();
    }

    public Map<String, Long> snapshot() {
        Map<String, Long> result = new ConcurrentHashMap<>();
        counters.forEach((k, v) -> result.put(k, v.get()));
        return result;
    }
}
