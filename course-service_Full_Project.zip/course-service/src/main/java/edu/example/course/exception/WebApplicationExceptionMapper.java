package edu.example.course.exception;

import edu.example.course.dto.ErrorResponse;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

/**
 * BadRequestException (400), NotFoundException (404) сияқты барлық
 * jakarta.ws.rs ерекшеліктерін бірыңғай ErrorResponse JSON пішініне
 * келтіреді — лаб2-дегі ErrorServlet идеясының JAX-RS нұсқасы.
 */
@Provider
public class WebApplicationExceptionMapper implements ExceptionMapper<WebApplicationException> {

    @Override
    public Response toResponse(WebApplicationException exception) {
        int status = exception.getResponse().getStatus();
        return Response.status(status)
                .type(MediaType.APPLICATION_JSON)
                .entity(new ErrorResponse(status, exception.getMessage()))
                .build();
    }
}
