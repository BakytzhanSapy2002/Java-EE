package edu.example.course.filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

/**
 * Әр сұранысқа бірегей X-Request-Id беріледі (кіріс сұраныста бар болса, сол қолданылады —
 * мысалы, клиент өзі жіберсе; жоқ болса, жаңасы жасалады). Жауапта да сол тақырып қайтады,
 * сондықтан логтар мен клиент арасында бір сұранысты байланыстыруға болады.
 *
 * Тізбектегі орны МАҢЫЗДЫ: бұл filter LoggingFilter-ден БҰРЫН тұруы керек,
 * сонда logging ID-ні жазғанда ол әлдеқашан белгіленген болады. Тәртіп
 * web.xml-дегі <filter-mapping> ретімен анықталады, @WebFilter емес.
 */
public class CorrelationIdFilter extends HttpFilter {

    public static final String HEADER = "X-Request-Id";
    public static final String ATTRIBUTE = "requestId";

    @Override
    protected void doFilter(HttpServletRequest req, HttpServletResponse resp, FilterChain chain)
            throws IOException, ServletException {
        String requestId = req.getHeader(HEADER);
        if (requestId == null || requestId.isBlank()) {
            requestId = UUID.randomUUID().toString();
        }
        req.setAttribute(ATTRIBUTE, requestId);
        resp.setHeader(HEADER, requestId);
        chain.doFilter(req, resp);
    }
}
