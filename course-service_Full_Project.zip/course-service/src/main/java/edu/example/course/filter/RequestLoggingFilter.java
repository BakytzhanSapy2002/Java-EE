package edu.example.course.filter;

import edu.example.course.observability.MetricsRegistry;
import jakarta.inject.Inject;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Әр сұранысты логқа жазады және есептейді. chain.doFilter(...) шақыруы —
 * нақты сервлетті орындайды; біз тек ОНЫҢ алдында мен соңында уақыт пен
 * нәтижені өлшейміз ("айналма" — around advice).
 *
 * try/finally маңызды: сервлет қате лақтырса да (мысалы, 500), лог жазылуы керек.
 *
 * 10-лаб: лог форматы құрылымды (бір жолдағы key=value жұптары) болды —
 * мұндай форматты лог жинау жүйелері (ELK, Loki) оңай талдай алады.
 * Сонымен қатар MetricsRegistry-ге сұраныс/қате санын жазамыз.
 *
 * ЕСКЕРТУ: @Inject осы жерде жұмыс істеуі үшін WEB-INF/beans.xml болуы керек —
 * сонда CDI контейнер Filter-ді де "басқарылатын бин" ретінде таниды.
 */
public class RequestLoggingFilter extends HttpFilter {

    @Inject
    private MetricsRegistry metrics;

    @Override
    protected void doFilter(HttpServletRequest req, HttpServletResponse resp, FilterChain chain)
            throws IOException, ServletException {
        long start = System.nanoTime();
        String requestId = String.valueOf(req.getAttribute(CorrelationIdFilter.ATTRIBUTE));
        try {
            chain.doFilter(req, resp);
        } finally {
            long elapsedMs = (System.nanoTime() - start) / 1_000_000;
            int status = resp.getStatus();

            getServletContext().log(String.format(
                "requestId=%s method=%s uri=%s status=%d durationMs=%d",
                requestId, req.getMethod(), req.getRequestURI(), status, elapsedMs));

            if (metrics != null) {
                metrics.increment("http.requests.total");
                if (status >= 500) metrics.increment("http.requests.serverErrors");
                else if (status >= 400) metrics.increment("http.requests.clientErrors");
            }
        }
    }
}
