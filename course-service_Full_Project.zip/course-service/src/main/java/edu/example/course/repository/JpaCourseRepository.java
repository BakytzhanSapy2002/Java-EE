package edu.example.course.repository;

import edu.example.course.model.Course;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;
import java.util.Optional;

/**
 * 6-лабтан бастап: EntityManagerFactory-ды қолмен жасамаймыз, транзакцияны
 * қолмен begin/commit жасамаймыз — CDI контейнер (TomEE) мұның бәрін
 * @PersistenceContext пен @Transactional арқылы өзі істейді (JTA).
 * Транзакция шекарасы енді CourseService-те (сервис қабаты), репозитории
 * ТЕК деректер амалдарын орындайды.
 */
@ApplicationScoped
public class JpaCourseRepository implements CourseRepository {

    @PersistenceContext(unitName = "course-service-pu")
    private EntityManager em;

    @Override
    public List<Course> findAll() {
        return em.createQuery("SELECT c FROM Course c ORDER BY c.id", Course.class).getResultList();
    }

    @Override
    public Optional<Course> findById(long id) {
        return Optional.ofNullable(em.find(Course.class, id));
    }

    @Override
    public Course save(Course course) {
        em.persist(course);
        return course;
    }

    @Override
    public boolean existsByCode(String code) {
        Long count = em.createQuery(
                "SELECT COUNT(c) FROM Course c WHERE LOWER(c.code) = LOWER(:code)", Long.class)
                .setParameter("code", code)
                .getSingleResult();
        return count > 0;
    }

    @Override
    public Optional<Course> update(long id, String code, String title) {
        Course course = em.find(Course.class, id);
        if (course == null) return Optional.empty();
        course.setCode(code);
        course.setTitle(title);
        return Optional.of(course);   // dirty checking — tx.commit() кезінде UPDATE өзі жүреді
    }

    @Override
    public boolean deleteById(long id) {
        Course course = em.find(Course.class, id);
        if (course == null) return false;
        em.remove(course);
        return true;
    }
}
