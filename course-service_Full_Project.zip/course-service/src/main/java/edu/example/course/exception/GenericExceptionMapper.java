package edu.example.course.exception;

import edu.example.course.dto.ErrorResponse;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Күтпеген (RuntimeException, NullPointerException, т.б.) кез келген
 * қате осы жерде ұсталады. Stack trace ЕШҚАШАН клиентке шықпайды —
 * тек серверлік логқа (Security and error handling талабы).
 */
@Provider
public class GenericExceptionMapper implements ExceptionMapper<Exception> {

    private static final Logger LOG = Logger.getLogger(GenericExceptionMapper.class.getName());

    @Override
    public Response toResponse(Exception exception) {
        LOG.log(Level.SEVERE, "Ұсталмаған қате", exception);
        return Response.status(500)
                .type(MediaType.APPLICATION_JSON)
                .entity(new ErrorResponse(500, "Internal Server Error"))
                .build();
    }
}
