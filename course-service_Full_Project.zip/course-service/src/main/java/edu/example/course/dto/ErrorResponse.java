package edu.example.course.dto;

import java.util.List;

/** Барлық API қатесі осы пішінде қайтарылады (3, 5-лаб). */
public record ErrorResponse(boolean error, int status, String message, List<String> details) {
    public ErrorResponse(int status, String message) {
        this(true, status, message, List.of());
    }
    public ErrorResponse(int status, String message, List<String> details) {
        this(true, status, message, details);
    }
}
