package edu.example.course;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

/**
 * JAX-RS-ті белсендіреді және базалық жолды белгілейді: барлық REST
 * endpoint-тер енді /course-service/api/... астында болады.
 * Көптеген контейнерлер (соның ішінде TomEE) @Path аннотациясы бар
 * класстарды өздігінен тауып алады, бірақ бұл класс портативтілік
 * үшін (басқа контейнерге көшкенде де жұмыс істеуі үшін) ұсынылады.
 */
@ApplicationPath("/api")
public class RestActivator extends Application {
}
