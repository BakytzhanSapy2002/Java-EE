package edu.example.course.repository;

import edu.example.course.model.Course;
import java.util.List;
import java.util.Optional;

/**
 * Деректермен жұмыстың келісімшарты. 2-лабта жалғыз іске асырылуы
 * InMemoryCourseRepository, 4-лабта JpaCourseRepository қосылады.
 * CoursesServlet (кейін JAX-RS ресурсы) тек осы интерфейспен жұмыс істейді —
 * нақты сақтау тәсілін білмейді.
 */
public interface CourseRepository {
    List<Course> findAll();
    Optional<Course> findById(long id);
    Course save(Course course);
    boolean existsByCode(String code);

    /** Толық CRUD үшін (3-лаб): жаңарту және жою. */
    Optional<Course> update(long id, String code, String title);
    boolean deleteById(long id);
}
