package edu.example.course;

import edu.example.course.dto.CourseDto;
import edu.example.course.dto.CourseInput;
import edu.example.course.model.Course;
import edu.example.course.service.CourseService;
import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import java.net.URI;
import java.util.List;

/**
 * Транспорт қабаты: HTTP ↔ Java шақыруын аударады. Бизнес-ереже (duplicate
 * тексеру, валидация) мұнда ЖОҚ — бәрі CourseService-те (6-лаб). Бұл
 * класс endpoint-тер мен DTO-ларды ғана біледі.
 *
 * Эволюция: HttpServlet (2-лаб) → @PostConstruct+ServletContext іздеу (3-лаб)
 * → @Inject CDI (6-лаб). Әр қадамда СЫРТҚЫ келісімшарт (HTTP API) бірдей қалды.
 */
@Path("/courses")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CoursesResource {

    @Inject
    private CourseService service;

    @GET
    @RolesAllowed({"student", "teacher"})
    public List<CourseDto> list(@QueryParam("limit") Integer limit) {
        return service.list(limit).stream().map(CourseDto::from).toList();
    }

    @GET
    @Path("/{id}")
    @RolesAllowed({"student", "teacher"})
    public CourseDto getOne(@PathParam("id") long id) {
        return CourseDto.from(service.get(id));
    }

    @POST
    @RolesAllowed("teacher")   // тек мұғалім жаңа курс қоса алады (7-лаб)
    public Response create(@Valid CourseInput input) {
        Course saved = service.create(input);
        URI location = UriBuilder.fromResource(CoursesResource.class)
                .path(String.valueOf(saved.getId())).build();
        return Response.created(location).entity(CourseDto.from(saved)).build();
    }

    @PUT
    @Path("/{id}")
    @RolesAllowed("teacher")
    public CourseDto update(@PathParam("id") long id, @Valid CourseInput input) {
        return CourseDto.from(service.update(id, input));
    }

    @DELETE
    @Path("/{id}")
    @RolesAllowed("teacher")
    public Response delete(@PathParam("id") long id) {
        service.delete(id);
        return Response.noContent().build();
    }
}
