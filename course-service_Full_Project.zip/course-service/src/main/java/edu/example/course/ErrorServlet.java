package edu.example.course;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Орталықтандырылған қате өңдеуші. web.xml ішінде <error-page> арқылы
 * 404, 405 және 500 кодтарына (сонымен қатар кез келген ұсталмаған Exception-ға)
 * осы сервлет тағайындалады.
 *
 * Мақсаты: Tomcat-тың әдепкі HTML бетінің (ол stack trace, сервер нұсқасын
 * және ішкі жол атауларын көрсетіп, қауіпсіздік тұрғысынан ақпарат
 * "ағызып" жіберуі мүмкін) орнына БІРЫҢҒАЙ, қауіпсіз JSON жауап қайтару.
 */
@WebServlet("/error-handler")
public class ErrorServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        handle(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        handle(req, resp);
    }

    private void handle(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Integer statusCode = (Integer) req.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        String requestUri = (String) req.getAttribute(RequestDispatcher.ERROR_REQUEST_URI);
        Throwable exception = (Throwable) req.getAttribute(RequestDispatcher.ERROR_EXCEPTION);

        int status = statusCode != null ? statusCode : HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
        String safeMessage = describeStatus(status);

        // МАҢЫЗДЫ: exception.getMessage() немесе stack trace-ті клиентке ЕШҚАШАН шығармаймыз.
        // Ол тек серверлік логқа (мысалы, RequestLoggingFilter арқылы) жазылады.
        if (exception != null) {
            getServletContext().log("Ұсталмаған қате: " + requestUri, exception);
        }

        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(String.format(
            "{\"error\":true,\"status\":%d,\"message\":\"%s\",\"path\":\"%s\"}",
            status, safeMessage, requestUri == null ? "" : requestUri));
    }

    private static String describeStatus(int status) {
        return switch (status) {
            case 400 -> "Bad Request";
            case 404 -> "Not Found";
            case 405 -> "Method Not Allowed";
            case 500 -> "Internal Server Error";
            default -> "Error";
        };
    }
}
