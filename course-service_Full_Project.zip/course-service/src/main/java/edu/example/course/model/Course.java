package edu.example.course.model;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * 2-лабта қарапайым POJO болатын, 4-лабтан бастап JPA кестесі.
 * Маңызды өзгерістер (2-лабпен салыстырғанда):
 *   - Id енді AtomicLong-пен қолмен емес, дерекқор арқылы (@GeneratedValue) беріледі.
 *   - Өрістер final БОЛМАУЫ керек — JPA провайдері (Hibernate/EclipseLink)
 *     рефлексия арқылы мән қоюы керек.
 *   - Бос конструктор МІНДЕТТІ (JPA спецификациясы солай талап етеді).
 */
@Entity
@Table(name = "courses")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 20)
    private String code;

    @Column(nullable = false, length = 120)
    private String title;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Enrollment> enrollments = new ArrayList<>();

    /** JPA-ға арналған бос конструктор. Қолданба коды оны ШАҚЫРМАЙДЫ. */
    protected Course() { }

    public Course(String code, String title) {
        this.code = code;
        this.title = title;
        this.createdAt = Instant.now();
    }

    public Long getId() { return id; }

    /**
     * Тек репозиторий іске асыруларына (мысалы, тесттегі FakeCourseRepository)
     * арналған. Нағыз JpaCourseRepository мұны ЕШҚАШАН шақырмайды — id-ні
     * em.persist() кезінде JPA провайдерінің өзі (рефлексия арқылы) қояды.
     * Бизнес-код (CourseService, CoursesResource) бұл әдісті шақырмауы керек.
     */
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public Instant getCreatedAt() { return createdAt; }
    public List<Enrollment> getEnrollments() { return enrollments; }
}
