package edu.example.course;

import edu.example.course.repository.CourseRepository;
import jakarta.inject.Inject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 10-лаб: /health (1-лаб) тек "процесс тірі ме?" дегенді білдіреді.
 * /health/ready ОДАН ТЕРЕҢІРЕК тексереді: дерекқорға нақты қосыла ала ма?
 * Бұл айырмашылық Kubernetes-тегі liveness/readiness probe ұғымына сәйкес келеді.
 */
@WebServlet("/health/ready")
public class ReadinessServlet extends HttpServlet {

    @Inject
    private CourseRepository repository;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        try {
            repository.findAll();   // нақты SELECT жібереді — DB байланысын тексереді
            resp.setStatus(HttpServletResponse.SC_OK);
            resp.getWriter().write("{\"status\":\"READY\",\"database\":\"UP\"}");
        } catch (RuntimeException e) {
            resp.setStatus(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
            resp.getWriter().write("{\"status\":\"NOT_READY\",\"database\":\"DOWN\"}");
            getServletContext().log("Readiness тексеруі сәтсіз", e);
        }
    }
}
