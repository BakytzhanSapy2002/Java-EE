package edu.example.course.listener;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

/**
 * 2-5 лабта бұл класс CourseRepository данасын қолмен жасап,
 * ServletContext-ке салатын. 6-лабтан бастап CDI (@Inject, @ApplicationScoped)
 * дәл осы жауапкершілікті алады — JpaCourseRepository мен CourseService-ті
 * контейнердің өзі басқарады. Listener ЕНДІ тек деплой/тоқтату логы үшін қалды.
 *
 * Бұл — бұрынғы қолмен жазылған "DI" (Dependency Injection) кодының нағыз
 * CDI контейнерімен қалай алмастырылатынының нақты мысалы.
 */
@WebListener
public class AppLifecycleListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        sce.getServletContext().log("course-service: қосымша іске қосылды (CDI контейнер басқарады)");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        sce.getServletContext().log("course-service: қосымша тоқтатылуда");
    }
}
