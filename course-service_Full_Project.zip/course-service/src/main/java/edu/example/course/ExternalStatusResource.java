package edu.example.course;

import edu.example.course.client.ExternalCourseInfoClient;
import edu.example.course.dto.ErrorResponse;
import edu.example.course.exception.UpstreamException;
import jakarta.annotation.security.PermitAll;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * 8-лаб демосы: сыртқы қызметке (мысалы, университеттің басқа микросервисіне)
 * timeout/retry-мен қоңырау шалу. Нақты практикада мұнда СOMPANY-ның шынайы
 * REST сервисінің URL-і болар еді — лаб үшін кез келген тестілік URL-ге
 * бағыттауға болады.
 */
@Path("/external-status")
@Produces(MediaType.APPLICATION_JSON)
public class ExternalStatusResource {

    // README-де айтылғандай system property/env арқылы өзгертуге болады
    private static final String EXTERNAL_BASE_URI =
            System.getProperty("external.service.uri", "http://localhost:9090");

    @GET
    @PermitAll
    public Response check() {
        try (ExternalCourseInfoClient client = new ExternalCourseInfoClient(EXTERNAL_BASE_URI)) {
            String body = client.fetchStatus("/health");
            return Response.ok("{\"upstream\":\"UP\",\"body\":" + quote(body) + "}").build();
        } catch (UpstreamException e) {
            // Сыртқы қызмет құлағанмен, БІЗДІҢ қызмет 503 деп жауап береді, 500 емес —
            // клиентке "мен жұмыс істеймін, бірақ менің тәуелділігім істемейді" дегенді білдіреді.
            return Response.status(503)
                    .entity(new ErrorResponse(503, "Сыртқы қызмет қолжетімсіз: " + e.getMessage()))
                    .build();
        }
    }

    private static String quote(String s) {
        return "\"" + (s == null ? "" : s.replace("\"", "\\\"")) + "\"";
    }
}
