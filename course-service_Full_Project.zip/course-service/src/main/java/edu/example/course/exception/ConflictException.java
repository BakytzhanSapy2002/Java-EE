package edu.example.course.exception;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;

/** JAX-RS спецификациясында дайын 409 ерекшелігі жоқ, сондықтан өзіміз жазамыз. */
public class ConflictException extends WebApplicationException {
    public ConflictException(String message) {
        super(message, Response.status(Response.Status.CONFLICT).build());
    }
}
