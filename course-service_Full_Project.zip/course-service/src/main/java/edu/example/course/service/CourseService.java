package edu.example.course.service;

import edu.example.course.dto.CourseInput;
import edu.example.course.exception.ConflictException;
import edu.example.course.model.Course;
import edu.example.course.repository.CourseRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.NotFoundException;
import java.util.List;

/**
 * 6-лаб: бизнес-ережелер (endpoint кодынан бөлек) осы жерде тұрады.
 * CoursesResource (транспорт қабаты) ЕНДІ репозиторийді тікелей білмейді —
 * тек осы сервисті шақырады. @Transactional — әдіс аяқталғанда
 * контейнер автоматты commit (немесе қате болса rollback) жасайды.
 */
@ApplicationScoped
public class CourseService {

    @Inject
    private CourseRepository repository;

    /** CDI осыны қолданады (параметрсіз). */
    public CourseService() { }

    /**
     * 9-лаб: тесттерге арналған конструктор. Field injection (@Inject жоғарыда)
     * CDI контейнерсіз тестілеуде қолайсыз — конструктор арқылы беру JUnit-те
     * ешқандай контейнерсіз, тікелей `new CourseService(fakeRepo)` жасауға мүмкіндік береді.
     */
    public CourseService(CourseRepository repository) {
        this.repository = repository;
    }

    public List<Course> list(Integer limit) {
        List<Course> courses = repository.findAll();
        if (limit != null) {
            if (limit < 0) throw new BadRequestException("limit теріс болмауы керек");
            courses = courses.stream().limit(limit).toList();
        }
        return courses;
    }

    public Course get(long id) {
        return repository.findById(id)
                .orElseThrow(() -> new NotFoundException("Id=" + id + " курсы табылмады"));
    }

    @Transactional
    public Course create(CourseInput input) {
        if (repository.existsByCode(input.code())) {
            throw new ConflictException("code='" + input.code() + "' бұрыннан бар");
        }
        return repository.save(new Course(input.code(), input.title()));
    }

    @Transactional
    public Course update(long id, CourseInput input) {
        return repository.update(id, input.code(), input.title())
                .orElseThrow(() -> new NotFoundException("Id=" + id + " курсы табылмады"));
    }

    @Transactional
    public void delete(long id) {
        if (!repository.deleteById(id)) {
            throw new NotFoundException("Id=" + id + " курсы табылмады");
        }
    }
}
