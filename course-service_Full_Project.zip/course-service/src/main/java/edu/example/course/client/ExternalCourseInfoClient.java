package edu.example.course.client;

import edu.example.course.exception.UpstreamException;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.ProcessingException;
import jakarta.ws.rs.core.Response;
import java.util.concurrent.TimeUnit;

/**
 * 8-лаб: сыртқы қызметті "сенімсіз желі" ретінде қарастырамыз — ол баяулауы,
 * қолжетімсіз болуы немесе қате қайтаруы мүмкін. Бұл класс үш қорғаныс
 * механизмін көрсетеді:
 *   1) Timeout — мәңгі күтпеу (connectTimeout, readTimeout).
 *   2) Retry — тек УАҚЫТША қателерде (5xx, желі қатесі) қайталау,
 *      4xx-те (клиент қатесі) ЕШҚАШАН қайталамау.
 *   3) Safe failure — сыртқы қызмет толық құласа да, біздің қызмет
 *      (course-service) өзі құламай, түсінікті UpstreamException лақтырады.
 */
public class ExternalCourseInfoClient implements AutoCloseable {

    private static final int MAX_ATTEMPTS = 3;
    private static final long BACKOFF_MS = 200;

    private final Client client;
    private final String baseUri;

    public ExternalCourseInfoClient(String baseUri) {
        this.baseUri = baseUri;
        this.client = ClientBuilder.newBuilder()
                .connectTimeout(2, TimeUnit.SECONDS)
                .readTimeout(3, TimeUnit.SECONDS)
                .build();
    }

    /** @return сыртқы қызметтің дене мәтіні. Сәтсіз болса UpstreamException. */
    public String fetchStatus(String path) {
        UpstreamException lastError = null;

        for (int attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            try (Response response = client.target(baseUri).path(path).request().get()) {
                if (response.getStatusInfo().getFamily() == Response.Status.Family.SUCCESSFUL) {
                    return response.readEntity(String.class);
                }

                if (response.getStatusInfo().getFamily() == Response.Status.Family.CLIENT_ERROR) {
                    // 4xx: қайталаудың мәні жоқ, біздің сұранысымыз дұрыс емес
                    throw new UpstreamException("Сыртқы қызмет 4xx қайтарды: " + response.getStatus());
                }

                // 5xx немесе басқа — уақытша болуы мүмкін, қайталап көреміз
                lastError = new UpstreamException("Сыртқы қызмет " + response.getStatus() + " қайтарды");
            } catch (ProcessingException e) {
                // Timeout немесе желі қатесі — де уақытша болуы мүмкін
                lastError = new UpstreamException("Сыртқы қызметке жету мүмкін болмады", e);
            }

            if (attempt < MAX_ATTEMPTS) {
                sleep(BACKOFF_MS * attempt);   // экспоненциалды емес, қарапайым сызықты backoff
            }
        }

        throw lastError;
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void close() {
        client.close();
    }
}
