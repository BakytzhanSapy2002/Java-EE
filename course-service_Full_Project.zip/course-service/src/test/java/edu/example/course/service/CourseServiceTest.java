package edu.example.course.service;

import edu.example.course.dto.CourseInput;
import edu.example.course.exception.ConflictException;
import edu.example.course.model.Course;
import jakarta.ws.rs.NotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** 9-лаб: CourseService бизнес-ережелеріне арналған unit тесттер (дерекқорсыз). */
class CourseServiceTest {

    private CourseService service;

    @BeforeEach
    void setUp() {
        service = new CourseService(new FakeCourseRepository());
    }

    @Test
    @DisplayName("Жаңа курс дұрыс деректермен сәтті жасалады")
    void createsCourseSuccessfully() {
        Course saved = service.create(new CourseInput("WEB101", "Web Services"));

        assertNotNull(saved, "сақталған курс null болмауы керек");
        assertEquals("WEB101", saved.getCode());
        assertEquals("Web Services", saved.getTitle());
    }

    @Test
    @DisplayName("Қайталанған code болса, ConflictException лақтырылады")
    void duplicateCodeThrowsConflict() {
        service.create(new CourseInput("WEB101", "Web Services"));

        assertThrows(ConflictException.class, () ->
                service.create(new CourseInput("WEB101", "Duplicate Title")));
    }

    @Test
    @DisplayName("Жоқ Id бойынша get() NotFoundException лақтырады")
    void getMissingThrowsNotFound() {
        assertThrows(NotFoundException.class, () -> service.get(999L));
    }

    @Test
    @DisplayName("limit теріс болса, BadRequestException лақтырылады")
    void negativeLimitThrowsBadRequest() {
        assertThrows(jakarta.ws.rs.BadRequestException.class, () -> service.list(-1));
    }

    @Test
    @DisplayName("list(limit) нәтижені дұрыс қысқартады")
    void listRespectsLimit() {
        service.create(new CourseInput("A1", "Course A"));
        service.create(new CourseInput("B1", "Course B"));
        service.create(new CourseInput("C1", "Course C"));

        assertEquals(2, service.list(2).size(), "limit=2 кезінде тек 2 курс қайтуы керек");
    }

    @Test
    @DisplayName("Курсты жаңарту жаңа code/title сақтайды")
    void updateChangesFields() {
        Course saved = service.create(new CourseInput("OLD1", "Old Title"));

        Course updated = service.update(saved.getId(), new CourseInput("NEW1", "New Title"));

        assertEquals("NEW1", updated.getCode());
        assertEquals("New Title", updated.getTitle());
    }

    @Test
    @DisplayName("Курсты жою кейін get() NotFoundException береді")
    void deleteRemovesCourse() {
        Course saved = service.create(new CourseInput("DEL1", "To delete"));

        service.delete(saved.getId());

        assertThrows(NotFoundException.class, () -> service.get(saved.getId()));
    }
}
