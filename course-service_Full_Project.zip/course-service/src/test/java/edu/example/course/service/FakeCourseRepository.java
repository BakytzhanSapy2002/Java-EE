package edu.example.course.service;

import edu.example.course.model.Course;
import edu.example.course.repository.CourseRepository;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Тест-дубльдеме (test double): дерекқорсыз, толықтай жадыда.
 * JUnit тестінде нағыз TomEE/H2 керек емес — бизнес-ережені (CourseService)
 * оқшауланған түрде тексереміз ("Unit tests isolate deterministic business rules").
 */
class FakeCourseRepository implements CourseRepository {

    private final Map<Long, Course> data = new LinkedHashMap<>();
    private final AtomicLong seq = new AtomicLong();

    @Override
    public List<Course> findAll() { return new ArrayList<>(data.values()); }

    @Override
    public Optional<Course> findById(long id) { return Optional.ofNullable(data.get(id)); }

    @Override
    public Course save(Course course) {
        long id = seq.incrementAndGet();
        course.setId(id);   // нағыз JPA-да provider автоматты қояды, фейкте өзіміз қоямыз
        data.put(id, course);
        return course;
    }

    @Override
    public boolean existsByCode(String code) {
        return data.values().stream().anyMatch(c -> c.getCode().equalsIgnoreCase(code));
    }

    @Override
    public Optional<Course> update(long id, String code, String title) {
        Course c = data.get(id);
        if (c == null) return Optional.empty();
        c.setCode(code);
        c.setTitle(title);
        return Optional.of(c);
    }

    @Override
    public boolean deleteById(long id) { return data.remove(id) != null; }
}
