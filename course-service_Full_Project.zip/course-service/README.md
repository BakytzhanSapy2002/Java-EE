# course-service

WSD4302 курсының кумулятивті зертханалық жобасы (10 лаб, бір Maven/Git репозиторийі).
Толық нұсқаулық: `course-service_Full_Guide.docx`.

## Қазіргі жағдайы: барлық 10 лаб аяқталған

| Лаб | Не қосылды |
|---|---|
| 1 | `/health` (HealthServlet) |
| 2 | `/courses` (сервлет), Filter тізбегі, Listener, орталықтандырылған қате өңдеу |
| 3 | JAX-RS (`CoursesResource`), DTO, толық CRUD, ExceptionMapper |
| 4 | JPA: Course/Student/Enrollment, JpaCourseRepository (RESOURCE_LOCAL) |
| 5 | Bean Validation (@Valid), ValidationExceptionMapper, openapi.yaml |
| 6 | CDI: CourseService, @Transactional, JTA (resources.xml) |
| 7 | RBAC: @RolesAllowed, BASIC auth (web.xml security-constraint) |
| 8 | ExternalCourseInfoClient: timeout/retry, /api/external-status |
| 9 | JUnit5 тесттер (CourseServiceTest), Dockerfile |
| 10 | /health/ready, MetricsRegistry, /api/metrics, құрылымды лог |

## Талаптар

- JDK 21, Maven 3.9+, Git
- **Apache TomEE 10.1.x Web Profile** (3-лабтан бастап — таза Tomcat ЖЕТКІЛІКСІЗ, себебі JAX-RS/CDI/JPA/Bean Validation керек)
- curl немесе Postman/Insomnia

## Құрастыру

```
mvn clean verify
```

## Тесттерді іске қосу

```
mvn test
```

## Іске қосу (TomEE)

```
copy target\course-service.war C:\tomee\apache-tomee-10.1.x-webprofile\webapps\
C:\tomee\apache-tomee-10.1.x-webprofile\bin\catalina.bat run
```

## Іске қосу (Docker)

```
docker build -t course-service:1.0 .
docker run --rm -p 8080:8080 course-service:1.0
```

## Тексеру

```
curl -i http://localhost:8080/course-service/health
curl -i http://localhost:8080/course-service/health/ready
curl -i -u aigerim:secret123 http://localhost:8080/course-service/api/courses
curl -i -u prof:secret456 -X POST -H "Content-Type: application/json" ^
  -d "{\"code\":\"WEB101\",\"title\":\"Web Services\"}" ^
  http://localhost:8080/course-service/api/courses
curl -i http://localhost:8080/course-service/api/metrics
curl -i http://localhost:8080/course-service/openapi.yaml
```

Пайдаланушылар (`conf/tomcat-users.xml`-ге қосу керек, 7-лабты қараңыз):
`aigerim/secret123` (student), `prof/secret456` (teacher).

## Белгілі шектеу

H2 дерекқоры жадыда (`jdbc:h2:mem:...`) жұмыс істейді — сервер қайта қосылғанда
деректер жойылады. Бұл оқу мақсатына жеткілікті (10-лабтың "Жиі кездесетін
мәселелер" бөлімін қараңыз).
